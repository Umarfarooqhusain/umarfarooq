import Image from 'next/image';

import FadeIn from '@/app/components/animations/FadeIn';
import Stagger from '@/app/components/animations/Stagger';
import StaggerItem from '@/app/components/animations/StaggerItem';

import Container from '@/app/components/ui/Container';
import Card from '@/app/components/ui/Card';
import Badge from '@/app/components/ui/Badge';
import Button from '@/app/components/ui/Button';
import SectionHeading from '@/app/components/ui/SectionHeading';

import { projects } from '@/app/data/projects';

export default function Projects() {
  return (
    <section>
      <Container className="pt-7">
        {/* Heading */}
        <FadeIn>
          <SectionHeading
            label="Projects"
            title="Featured Work"
            description="A selection of projects that showcase my ability to design and build modern web applications."
          />
        </FadeIn>

        {/* Project Cards */}
        <Stagger>
          <div className="mt-14 space-y-8">
            {projects.map(project => (
              <StaggerItem key={project.title}>
                <Card
                  className="
                    overflow-hidden
                    grid
                    grid-cols-1
                    lg:grid-cols-2
                    group
                    hover:border-blue-500
                    hover:shadow-2xl
                    hover:shadow-blue-500/10
                  "
                >
                  {/* Image */}
                  <div className="relative h-[300px] overflow-hidden">
                    <Image
                      src={project.image}
                      alt={project.title}
                      fill
                      className="
                        object-cover
                        smooth
                        group-hover:scale-110
                      "
                    />

                    <div
                      className="
                        absolute
                        inset-0
                        bg-gradient-to-t
                        from-black/60
                        to-transparent
                      "
                    />
                  </div>

                  {/* Content */}
                  <div
                    className="
                      p-8
                      flex
                      flex-col
                      justify-center
                    "
                  >
                    <h3 className="text-3xl font-bold">{project.title}</h3>

                    <p className="mt-4 text-lg">{project.description}</p>

                    {/* Technologies */}
                    <div className="mt-6 flex flex-wrap gap-3">
                      {project.technologies.map(tech => (
                        <Badge key={tech}>{tech}</Badge>
                      ))}
                    </div>

                    {/* Buttons */}
                    <div className="mt-8 flex gap-4">
                      <Button href={project.github}>GitHub</Button>

                      <Button href={project.live} variant="secondary">
                        Live Demo
                      </Button>
                    </div>
                  </div>
                </Card>
              </StaggerItem>
            ))}
          </div>
        </Stagger>
      </Container>
    </section>
  );
}
