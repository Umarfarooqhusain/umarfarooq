import { Project } from "@/app/types/project";

export const projects: Project[] = [
  {
    title: "ArmRage E-Commerce",
    description:
      "A modern e-commerce platform for arm wrestling equipment with responsive design and a smooth shopping experience.",
    technologies: [
      "Next.js",
      "TypeScript",
      "Tailwind CSS",
    ],
    image: "/images/armrage.png",
    github: "https://github.com/yourusername/armrage",
    live: "https://armrage.com",
  },

  {
    title: "Task Management App",
    description:
      "A productivity application that helps users manage tasks, workflows, and daily goals.",
    technologies: [
      "Next.js",
      "MongoDB",
      "Authentication",
    ],
    image: "/images/task-app.png",
    github: "https://github.com/yourusername/task-manager",
    live: "https://task-demo.com",
  },

  {
    title: "AI SaaS Application",
    description:
      "An AI-powered platform that helps users generate content and improve productivity.",
    technologies: [
      "Next.js",
      "AI API",
      "Database",
    ],
    image: "/images/ai-saas.png",
    github: "https://github.com/yourusername/ai-saas",
    live: "https://ai-demo.com",
  },
];