import { SkillCategory } from '@/app/types/skill';

export const skills: SkillCategory[] = [
  {
    title: 'Frontend',
    skills: [
      'Next.js',
      'HTML',
      'CSS',
      'JavaScript',
      'TypeScript',
      'React',
      'Tailwind CSS',
    ],
  },

  {
    title: 'Currently Learning',
    skills: ['APIs', 'MongoDB', 'Authentication', 'Full-Stack Development'],
  },

  {
    title: 'Tools',
    skills: ['Git', 'GitHub', 'VS Code', 'Vercel', 'Figma'],
  },
];
