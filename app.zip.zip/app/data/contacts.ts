import { Contact } from "@/app/types/contact";
import { LINKS } from "@/app/constants/links";

export const contacts: Contact[] = [
  {
    title: "Email",
    value: "umar@example.com",
    href: LINKS.email,
    icon: "📧",
  },

  {
    title: "GitHub",
    value: "github.com/yourusername",
    href: LINKS.github,
    icon: "💻",
  },

  {
    title: "LinkedIn",
    value: "linkedin.com/in/yourusername",
    href: LINKS.linkedin,
    icon: "💼",
  },
];