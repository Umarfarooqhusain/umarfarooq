import { JourneyItem } from "@/app/types/journey";

export const journey: JourneyItem[] = [
  {
    year: "2023",
    title: "Electrical Engineering Foundation",
    description:
      "Completed my Diploma in Electrical Engineering from Jamia Millia Islamia, building strong technical and analytical skills.",
  },

  {
    year: "2025",
    title: "Started Web Development",
    description:
      "Started learning modern web technologies including HTML, CSS, JavaScript, React, and Next.js.",
  },

  {
    year: "2026",
    title: "Built Real Projects",
    description:
      "Created ArmRage and started building professional applications using modern development practices.",
  },

  {
    year: "Present",
    title: "Growing Into Full-Stack Development",
    description:
      "Currently learning APIs, databases, authentication, and backend architecture.",
  },
];